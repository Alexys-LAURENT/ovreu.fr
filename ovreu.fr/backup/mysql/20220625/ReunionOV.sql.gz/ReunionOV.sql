-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: ReunionOV
-- ------------------------------------------------------
-- Server version	8.0.29-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ReunionOV`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ReunionOV` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ReunionOV`;

--
-- Table structure for table `Reunion`
--

DROP TABLE IF EXISTS `Reunion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reunion` (
  `idreunion` int NOT NULL AUTO_INCREMENT,
  `datereunion` date NOT NULL,
  `libelle` varchar(150) DEFAULT NULL,
  `idsalarie` int NOT NULL,
  PRIMARY KEY (`idreunion`),
  KEY `idsalarie` (`idsalarie`),
  CONSTRAINT `Reunion_ibfk_1` FOREIGN KEY (`idsalarie`) REFERENCES `Salarie` (`idsalarie`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=406 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reunion`
--

LOCK TABLES `Reunion` WRITE;
/*!40000 ALTER TABLE `Reunion` DISABLE KEYS */;
INSERT INTO `Reunion` VALUES (1,'2022-11-30','Entretien technique numero 1 ',1),(2,'2023-11-30','Entretien technique numero 1 ',1),(3,'2024-11-30','Entretien technique numero 1 ',1),(4,'2025-11-30','Entretien technique numero 1 ',1),(5,'2026-11-30','Entretien technique numero 1 ',1),(6,'2027-11-30','Entretien technique numero 1 ',1),(7,'2028-11-30','Entretien technique numero 1 ',1),(8,'2029-11-30','Entretien technique numero 1 ',1),(9,'2030-11-30','Entretien technique numero 1 ',1),(10,'2031-11-30','Entretien technique numero 1 ',1),(11,'2032-11-30','Entretien technique numero 1 ',1),(12,'2033-11-30','Entretien technique numero 1 ',1),(13,'2034-11-30','Entretien technique numero 1 ',1),(14,'2035-11-30','Entretien technique numero 1 ',1),(15,'2036-11-30','Entretien technique numero 1 ',1),(16,'2037-11-30','Entretien technique numero 1 ',1),(17,'2038-11-30','Entretien technique numero 1 ',1),(18,'2039-11-30','Entretien technique numero 1 ',1),(19,'2040-11-30','Entretien technique numero 1 ',1),(20,'2041-11-30','Entretien technique numero 1 ',1),(21,'2042-11-30','Entretien technique numero 1 ',1),(22,'2023-05-30','Entretien technique numero 2 ',1),(23,'2024-05-30','Entretien technique numero 2 ',1),(24,'2025-05-30','Entretien technique numero 2 ',1),(25,'2026-05-30','Entretien technique numero 2 ',1),(26,'2027-05-30','Entretien technique numero 2 ',1),(27,'2028-05-30','Entretien technique numero 2 ',1),(28,'2029-05-30','Entretien technique numero 2 ',1),(29,'2030-05-30','Entretien technique numero 2 ',1),(30,'2031-05-30','Entretien technique numero 2 ',1),(31,'2032-05-30','Entretien technique numero 2 ',1),(32,'2033-05-30','Entretien technique numero 2 ',1),(33,'2034-05-30','Entretien technique numero 2 ',1),(34,'2035-05-30','Entretien technique numero 2 ',1),(35,'2036-05-30','Entretien technique numero 2 ',1),(36,'2037-05-30','Entretien technique numero 2 ',1),(37,'2038-05-30','Entretien technique numero 2 ',1),(38,'2039-05-30','Entretien technique numero 2 ',1),(39,'2040-05-30','Entretien technique numero 2 ',1),(40,'2041-05-30','Entretien technique numero 2 ',1),(41,'2042-05-30','Entretien technique numero 2 ',1),(42,'2023-06-30','Entretien avec Michel ',1),(43,'2024-06-30','Entretien avec Michel ',1),(44,'2025-06-30','Entretien avec Michel ',1),(45,'2026-06-30','Entretien avec Michel ',1),(46,'2027-06-30','Entretien avec Michel ',1),(47,'2028-06-30','Entretien avec Michel ',1),(48,'2029-06-30','Entretien avec Michel ',1),(49,'2030-06-30','Entretien avec Michel ',1),(50,'2031-06-30','Entretien avec Michel ',1),(51,'2032-06-30','Entretien avec Michel ',1),(52,'2033-06-30','Entretien avec Michel ',1),(53,'2034-06-30','Entretien avec Michel ',1),(54,'2035-06-30','Entretien avec Michel ',1),(55,'2036-06-30','Entretien avec Michel ',1),(56,'2037-06-30','Entretien avec Michel ',1),(57,'2038-06-30','Entretien avec Michel ',1),(58,'2039-06-30','Entretien avec Michel ',1),(59,'2040-06-30','Entretien avec Michel ',1),(60,'2041-06-30','Entretien avec Michel ',1),(61,'2042-06-30','Entretien avec Michel ',1),(62,'2023-07-30','Entretien avec Guillaume ',1),(63,'2024-07-30','Entretien avec Guillaume ',1),(64,'2025-07-30','Entretien avec Guillaume ',1),(65,'2026-07-30','Entretien avec Guillaume ',1),(66,'2027-07-30','Entretien avec Guillaume ',1),(67,'2028-07-30','Entretien avec Guillaume ',1),(68,'2029-07-30','Entretien avec Guillaume ',1),(69,'2030-07-30','Entretien avec Guillaume ',1),(70,'2031-07-30','Entretien avec Guillaume ',1),(71,'2032-07-30','Entretien avec Guillaume ',1),(72,'2033-07-30','Entretien avec Guillaume ',1),(73,'2034-07-30','Entretien avec Guillaume ',1),(74,'2035-07-30','Entretien avec Guillaume ',1),(75,'2036-07-30','Entretien avec Guillaume ',1),(76,'2037-07-30','Entretien avec Guillaume ',1),(77,'2038-07-30','Entretien avec Guillaume ',1),(78,'2039-07-30','Entretien avec Guillaume ',1),(79,'2040-07-30','Entretien avec Guillaume ',1),(80,'2041-07-30','Entretien avec Guillaume ',1),(81,'2042-07-30','Entretien avec Guillaume ',1),(82,'2022-11-30','Entretien technique numero 1 ',1),(83,'2023-11-30','Entretien technique numero 1 ',1),(84,'2024-11-30','Entretien technique numero 1 ',1),(85,'2025-11-30','Entretien technique numero 1 ',1),(86,'2026-11-30','Entretien technique numero 1 ',1),(87,'2027-11-30','Entretien technique numero 1 ',1),(88,'2028-11-30','Entretien technique numero 1 ',1),(89,'2029-11-30','Entretien technique numero 1 ',1),(90,'2030-11-30','Entretien technique numero 1 ',1),(91,'2031-11-30','Entretien technique numero 1 ',1),(92,'2032-11-30','Entretien technique numero 1 ',1),(93,'2033-11-30','Entretien technique numero 1 ',1),(94,'2034-11-30','Entretien technique numero 1 ',1),(95,'2035-11-30','Entretien technique numero 1 ',1),(96,'2036-11-30','Entretien technique numero 1 ',1),(97,'2037-11-30','Entretien technique numero 1 ',1),(98,'2038-11-30','Entretien technique numero 1 ',1),(99,'2039-11-30','Entretien technique numero 1 ',1),(100,'2040-11-30','Entretien technique numero 1 ',1),(101,'2041-11-30','Entretien technique numero 1 ',1),(102,'2042-11-30','Entretien technique numero 1 ',1),(103,'2023-05-30','Entretien technique numero 2 ',1),(104,'2024-05-30','Entretien technique numero 2 ',1),(105,'2025-05-30','Entretien technique numero 2 ',1),(106,'2026-05-30','Entretien technique numero 2 ',1),(107,'2027-05-30','Entretien technique numero 2 ',1),(108,'2028-05-30','Entretien technique numero 2 ',1),(109,'2029-05-30','Entretien technique numero 2 ',1),(110,'2030-05-30','Entretien technique numero 2 ',1),(111,'2031-05-30','Entretien technique numero 2 ',1),(112,'2032-05-30','Entretien technique numero 2 ',1),(113,'2033-05-30','Entretien technique numero 2 ',1),(114,'2034-05-30','Entretien technique numero 2 ',1),(115,'2035-05-30','Entretien technique numero 2 ',1),(116,'2036-05-30','Entretien technique numero 2 ',1),(117,'2037-05-30','Entretien technique numero 2 ',1),(118,'2038-05-30','Entretien technique numero 2 ',1),(119,'2039-05-30','Entretien technique numero 2 ',1),(120,'2040-05-30','Entretien technique numero 2 ',1),(121,'2041-05-30','Entretien technique numero 2 ',1),(122,'2042-05-30','Entretien technique numero 2 ',1),(123,'2023-06-30','Entretien avec Michel ',1),(124,'2024-06-30','Entretien avec Michel ',1),(125,'2025-06-30','Entretien avec Michel ',1),(126,'2026-06-30','Entretien avec Michel ',1),(127,'2027-06-30','Entretien avec Michel ',1),(128,'2028-06-30','Entretien avec Michel ',1),(129,'2029-06-30','Entretien avec Michel ',1),(130,'2030-06-30','Entretien avec Michel ',1),(131,'2031-06-30','Entretien avec Michel ',1),(132,'2032-06-30','Entretien avec Michel ',1),(133,'2033-06-30','Entretien avec Michel ',1),(134,'2034-06-30','Entretien avec Michel ',1),(135,'2035-06-30','Entretien avec Michel ',1),(136,'2036-06-30','Entretien avec Michel ',1),(137,'2037-06-30','Entretien avec Michel ',1),(138,'2038-06-30','Entretien avec Michel ',1),(139,'2039-06-30','Entretien avec Michel ',1),(140,'2040-06-30','Entretien avec Michel ',1),(141,'2041-06-30','Entretien avec Michel ',1),(142,'2042-06-30','Entretien avec Michel ',1),(143,'2023-07-30','Entretien avec Guillaume ',1),(144,'2024-07-30','Entretien avec Guillaume ',1),(145,'2025-07-30','Entretien avec Guillaume ',1),(146,'2026-07-30','Entretien avec Guillaume ',1),(147,'2027-07-30','Entretien avec Guillaume ',1),(148,'2028-07-30','Entretien avec Guillaume ',1),(149,'2029-07-30','Entretien avec Guillaume ',1),(150,'2030-07-30','Entretien avec Guillaume ',1),(151,'2031-07-30','Entretien avec Guillaume ',1),(152,'2032-07-30','Entretien avec Guillaume ',1),(153,'2033-07-30','Entretien avec Guillaume ',1),(154,'2034-07-30','Entretien avec Guillaume ',1),(155,'2035-07-30','Entretien avec Guillaume ',1),(156,'2036-07-30','Entretien avec Guillaume ',1),(157,'2037-07-30','Entretien avec Guillaume ',1),(158,'2038-07-30','Entretien avec Guillaume ',1),(159,'2039-07-30','Entretien avec Guillaume ',1),(160,'2040-07-30','Entretien avec Guillaume ',1),(161,'2041-07-30','Entretien avec Guillaume ',1),(162,'2042-07-30','Entretien avec Guillaume ',1),(163,'2022-12-03','Entretien technique numero 1 ',2),(164,'2023-12-03','Entretien technique numero 1 ',2),(165,'2024-12-03','Entretien technique numero 1 ',2),(166,'2025-12-03','Entretien technique numero 1 ',2),(167,'2026-12-03','Entretien technique numero 1 ',2),(168,'2027-12-03','Entretien technique numero 1 ',2),(169,'2028-12-03','Entretien technique numero 1 ',2),(170,'2029-12-03','Entretien technique numero 1 ',2),(171,'2030-12-03','Entretien technique numero 1 ',2),(172,'2031-12-03','Entretien technique numero 1 ',2),(173,'2032-12-03','Entretien technique numero 1 ',2),(174,'2033-12-03','Entretien technique numero 1 ',2),(175,'2034-12-03','Entretien technique numero 1 ',2),(176,'2035-12-03','Entretien technique numero 1 ',2),(177,'2036-12-03','Entretien technique numero 1 ',2),(178,'2037-12-03','Entretien technique numero 1 ',2),(179,'2038-12-03','Entretien technique numero 1 ',2),(180,'2039-12-03','Entretien technique numero 1 ',2),(181,'2040-12-03','Entretien technique numero 1 ',2),(182,'2041-12-03','Entretien technique numero 1 ',2),(183,'2042-12-03','Entretien technique numero 1 ',2),(184,'2023-06-03','Entretien technique numero 2 ',2),(185,'2024-06-03','Entretien technique numero 2 ',2),(186,'2025-06-03','Entretien technique numero 2 ',2),(187,'2026-06-03','Entretien technique numero 2 ',2),(188,'2027-06-03','Entretien technique numero 2 ',2),(189,'2028-06-03','Entretien technique numero 2 ',2),(190,'2029-06-03','Entretien technique numero 2 ',2),(191,'2030-06-03','Entretien technique numero 2 ',2),(192,'2031-06-03','Entretien technique numero 2 ',2),(193,'2032-06-03','Entretien technique numero 2 ',2),(194,'2033-06-03','Entretien technique numero 2 ',2),(195,'2034-06-03','Entretien technique numero 2 ',2),(196,'2035-06-03','Entretien technique numero 2 ',2),(197,'2036-06-03','Entretien technique numero 2 ',2),(198,'2037-06-03','Entretien technique numero 2 ',2),(199,'2038-06-03','Entretien technique numero 2 ',2),(200,'2039-06-03','Entretien technique numero 2 ',2),(201,'2040-06-03','Entretien technique numero 2 ',2),(202,'2041-06-03','Entretien technique numero 2 ',2),(203,'2042-06-03','Entretien technique numero 2 ',2),(204,'2023-07-03','Entretien avec Michel ',2),(205,'2024-07-03','Entretien avec Michel ',2),(206,'2025-07-03','Entretien avec Michel ',2),(207,'2026-07-03','Entretien avec Michel ',2),(208,'2027-07-03','Entretien avec Michel ',2),(209,'2028-07-03','Entretien avec Michel ',2),(210,'2029-07-03','Entretien avec Michel ',2),(211,'2030-07-03','Entretien avec Michel ',2),(212,'2031-07-03','Entretien avec Michel ',2),(213,'2032-07-03','Entretien avec Michel ',2),(214,'2033-07-03','Entretien avec Michel ',2),(215,'2034-07-03','Entretien avec Michel ',2),(216,'2035-07-03','Entretien avec Michel ',2),(217,'2036-07-03','Entretien avec Michel ',2),(218,'2037-07-03','Entretien avec Michel ',2),(219,'2038-07-03','Entretien avec Michel ',2),(220,'2039-07-03','Entretien avec Michel ',2),(221,'2040-07-03','Entretien avec Michel ',2),(222,'2041-07-03','Entretien avec Michel ',2),(223,'2042-07-03','Entretien avec Michel ',2),(224,'2023-08-03','Entretien avec Guillaume ',2),(225,'2024-08-03','Entretien avec Guillaume ',2),(226,'2025-08-03','Entretien avec Guillaume ',2),(227,'2026-08-03','Entretien avec Guillaume ',2),(228,'2027-08-03','Entretien avec Guillaume ',2),(229,'2028-08-03','Entretien avec Guillaume ',2),(230,'2029-08-03','Entretien avec Guillaume ',2),(231,'2030-08-03','Entretien avec Guillaume ',2),(232,'2031-08-03','Entretien avec Guillaume ',2),(233,'2032-08-03','Entretien avec Guillaume ',2),(234,'2033-08-03','Entretien avec Guillaume ',2),(235,'2034-08-03','Entretien avec Guillaume ',2),(236,'2035-08-03','Entretien avec Guillaume ',2),(237,'2036-08-03','Entretien avec Guillaume ',2),(238,'2037-08-03','Entretien avec Guillaume ',2),(239,'2038-08-03','Entretien avec Guillaume ',2),(240,'2039-08-03','Entretien avec Guillaume ',2),(241,'2040-08-03','Entretien avec Guillaume ',2),(242,'2041-08-03','Entretien avec Guillaume ',2),(243,'2042-08-03','Entretien avec Guillaume ',2);
/*!40000 ALTER TABLE `Reunion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Salarie`
--

DROP TABLE IF EXISTS `Salarie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Salarie` (
  `idsalarie` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `dateembauche` date NOT NULL,
  PRIMARY KEY (`idsalarie`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Salarie`
--

LOCK TABLES `Salarie` WRITE;
/*!40000 ALTER TABLE `Salarie` DISABLE KEYS */;
INSERT INTO `Salarie` VALUES (1,'laurent','alexys','alexyslaurent.442@gmail.com','2022-05-30'),(2,'Lamouche','Louis','louis.lamouche2204@gmail.com','2022-06-03');
/*!40000 ALTER TABLE `Salarie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ReunionOV'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-25  0:00:01
